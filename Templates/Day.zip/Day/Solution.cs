﻿string[] input = File.ReadAllLines("Input.txt");
